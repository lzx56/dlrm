# GCP Samples

Big Query
------
TODO 

Storage
-------

TODO
