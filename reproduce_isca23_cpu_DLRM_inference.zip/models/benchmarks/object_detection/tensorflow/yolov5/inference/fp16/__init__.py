#
# -*- coding: utf-8 -*-
#
# Copyright (c) 2024 Intel Corporation
#
# AGPL-3.0 license
