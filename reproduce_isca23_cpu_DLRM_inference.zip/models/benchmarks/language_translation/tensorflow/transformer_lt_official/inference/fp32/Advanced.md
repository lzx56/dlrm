<!--- 0. Title -->
<!-- This document is auto-generated using markdown fragments and the model-builder -->
<!-- To make changes to this doc, please change the fragments instead of modifying this doc directly -->
# Transformer LT Official FP32 inference - Advanced Instructions

<!-- 10. Description -->
This document has advanced instructions for running Transformer LT Official FP32
inference, which provides more control over the individual parameters that
are used. For more information on using [`/benchmarks/launch_benchmark.py`](/benchmarks/launch_benchmark.py),
see the [launch benchmark documentation](/docs/general/tensorflow/LaunchBenchmark.md).

Prior to using these instructions, please follow the setup instructions from
the model's [README](README.md) and/or the
[AI Kit documentation](/docs/general/tensorflow/AIKit.md) to get your environment
setup (if running on bare metal) and download the dataset, pretrained model, etc.
If you are using AI Kit, please exclude the `--docker-image` flag from the
commands below, since you will be running the the TensorFlow conda environment
instead of docker.

<!-- 55. Docker arg -->
Any of the `launch_benchmark.py` commands below can be run on bare metal by
removing the `--docker-image` arg. Ensure that you have all of the
[required prerequisites installed](README.md#run-the-model) in your environment
before running without the docker container.

If you are new to docker and are running into issues with the container,
see [this document](/docs/general/docker.md) for troubleshooting tips.

<!-- 50. Launch benchmark instructions -->
Once your environment is setup, navigate to the `benchmarks` directory of
the model zoo and set environment variables for the dataset, checkpoint
directory, and an output directory where log files will be written.
```
cd benchmarks

export DATASET_DIR=<path to the dataset>
export OUTPUT_DIR=<directory where log files will be written>
export PRETRAINED_MODEL=<path to the pretrained model frozen graph .pb file>
```

Transformer LT official can run for online or batch inference. Use one of the
following examples below, depending on your use case.

For online inference (using `--socket-id 0` and `--batch-size 1`):
```
python launch_benchmark.py \
    --model-name transformer_lt_official \
    --precision fp32 \
    --mode inference \
    --framework tensorflow \
    --batch-size 1 \
    --socket-id 0 \
    --docker-image intel/intel-optimized-tensorflow:latest \
    --in-graph ${PRETRAINED_MODEL} \
    --data-location ${DATASET_DIR} \
    --output-dir ${OUTPUT_DIR} \
    -- file=newstest2014.en \
    file_out=translate.txt \
    reference=newstest2014.de \
    vocab_file=vocab.txt
```

For batch inference (using `--socket-id 0` and `--batch-size 64`):
```
python launch_benchmark.py \
    --model-name transformer_lt_official \
    --precision fp32 \
    --mode inference \
    --framework tensorflow \
    --batch-size 64 \
    --socket-id 0 \
    --docker-image intel/intel-optimized-tensorflow:latest \
    --in-graph ${PRETRAINED_MODEL} \
    --data-location ${DATASET_DIR} \
    --output-dir ${OUTPUT_DIR} \
    -- file=newstest2014.en \
    file_out=translate.txt \
    reference=newstest2014.de \
    vocab_file=vocab.txt

```

Note that the `--verbose` flag can be added to any of the above commands
to get additional debug output.
The num-inter-threads and num-intra-threads could be set different numbers
depending on the CPU in the system to achieve the best performance.

