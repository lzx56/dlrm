## Mask R-CNN ##

The following document has instructions for running Mask R-CNN:
* [FP32 inference](/benchmarks/recommendation/tensorflow/maskrcnn/inference/fp32/README.md)
