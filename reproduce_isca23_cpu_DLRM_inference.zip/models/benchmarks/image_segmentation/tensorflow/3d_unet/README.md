# 3D U-Net

The following document has instructions for running 3D U-Net:
* [FP32 inference](/benchmarks/image_segmentation/tensorflow/3d_unet/inference/fp32/README.md)
