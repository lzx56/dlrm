#!/usr/bin/bash -ex

${PYTHON} setup.py install
