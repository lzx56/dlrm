namespace torch_ipex {
namespace utils {

int onednn_set_verbose(int level);
bool onednn_has_bf16_type_support();

} // namespace utils
} // namespace torch_ipex
