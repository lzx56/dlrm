from ._quantize import prepare, convert
from ._qconfig import default_static_qconfig, default_dynamic_qconfig
