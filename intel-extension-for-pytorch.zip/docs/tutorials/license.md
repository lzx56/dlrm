License
=======

Intel® Extension for PyTorch\* is licensed under [Apache License Version 2.0](http://www.apache.org/licenses/LICENSE-2.0). This software includes components that have separate copyright notices and licensing terms. Your use of the source code for these components is subject to the terms and conditions of the following licenses.

Apache License Version 2.0:

[Intel® Extension for PyTorch\* LICENSE](https://github.com/intel/intel-extension-for-pytorch/blob/master/LICENSE.txt)

